package com.allvideodown.socialdownloader.interfaces;

public interface EncryptionCallbackNew {
    void onDataEncrypted(String encryptedData);

}
