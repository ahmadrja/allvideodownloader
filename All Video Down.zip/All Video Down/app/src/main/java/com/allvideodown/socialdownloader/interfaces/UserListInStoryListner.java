package com.allvideodown.socialdownloader.interfaces;


import com.allvideodown.socialdownloader.models.storymodels.ModelUsrTray;

public interface UserListInStoryListner {
    void onclickUserStoryListeItem(int position, ModelUsrTray modelUsrTray);
}
