package com.allvideodown.socialdownloader.facebookstorysaver.fbinterfaces;

public interface OnFbUserClicked {
    void onclick_on_user(String id);
}
