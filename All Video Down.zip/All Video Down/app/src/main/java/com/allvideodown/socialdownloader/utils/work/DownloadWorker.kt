/*
 * *
 * * Copyright (c) 2026. All rights reserved.
 * *
 */

package com.allvideodown.socialdownloader.utils.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.services.MyFirebaseMessagingService
import com.allvideodown.socialdownloader.utils.Constants
import com.allvideodown.socialdownloader.utils.Constants.directoryInstaShoryDirectorydownload_audio
import com.allvideodown.socialdownloader.utils.Constants.directoryInstaShoryDirectorydownload_images
import com.allvideodown.socialdownloader.utils.Constants.directoryInstaShoryDirectorydownload_videos
import com.allvideodown.socialdownloader.utils.iUtils
import com.allvideodown.socialdownloader.utils.iUtils.createFilenameWithJapneseAndOthers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.io.FilenameUtils
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class DownloadWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    private val notificationManager =
        appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager?

    override suspend fun doWork(): Result {
        val urlString = inputData.getString(urlKey) ?: return Result.failure()
        val rawName = inputData.getString(nameKey) ?: "download_${System.currentTimeMillis()}"
        val name = createFilenameWithJapneseAndOthers(rawName)
        val taskId = inputData.getString(taskIdKey) ?: id.toString()
        val ext = inputData.getString(extKey) ?: "mp4"

        createNotificationChannel()
        val notificationId = id.hashCode()
        val builder = NotificationCompat.Builder(applicationContext, iUtils.myNotificationChannel)
            .setSmallIcon(R.drawable.ic_download_yellow)
            .setContentTitle(name)
            .setSound(null)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .setContentText(applicationContext.getString(R.string.don_start))
            .setOngoing(true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            setForegroundAsync(
                ForegroundInfo(
                    notificationId,
                    builder.build(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            )
        } else {
            setForegroundAsync(ForegroundInfo(notificationId, builder.build()))
        }

        // डायरेक्ट्री सेटअप
        val myPath = getDownloadDirectoryPath(ext)
        val destDir = File(myPath)
        if (!destDir.exists()) {
            destDir.mkdirs()
        }

        val finalFileName = "${FilenameUtils.removeExtension(name)}_${System.currentTimeMillis()}${Constants.MY_ANDROID_IDENTIFIER_OF_FILE_DL}.$ext"
        val destFile = File(destDir, finalFileName)

        return try {
            withContext(Dispatchers.IO) {
                downloadFile(urlString, destFile, notificationId, taskId, name)
            }

            // सफलता का नोटिफिकेशन
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                MyFirebaseMessagingService.sendOreoNotification(
                    applicationContext,
                    applicationContext.resources.getString(R.string.app_name),
                    applicationContext.resources.getString(R.string.yourdoncomple)
                )
            } else {
                MyFirebaseMessagingService.sendNotification(
                    applicationContext,
                    applicationContext.resources.getString(R.string.app_name),
                    applicationContext.resources.getString(R.string.yourdoncomple)
                )
            }
            Result.success()
        } catch (e: Exception) {
            Log.e("DownloadWorker Error", e.message.toString())
            e.printStackTrace()
            if (destFile.exists()) destFile.delete() // फेल होने पर अधूरी फाइल डिलीट करें
            Result.failure()
        }
    }

    private fun getDownloadDirectoryPath(extension: String): String {
        val baseDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
        return when (extension.lowercase()) {
            "png", "jpg", "gif", "jpeg", "webp" -> baseDir + directoryInstaShoryDirectorydownload_images
            "mp4", "webm", "mkv" -> baseDir + directoryInstaShoryDirectorydownload_videos
            "mp3", "m4a", "wav" -> baseDir + directoryInstaShoryDirectorydownload_audio
            else -> baseDir + directoryInstaShoryDirectorydownload_videos
        }
    }

    private suspend fun downloadFile(
        fileUrl: String,
        destFile: File,
        notificationId: Int,
        taskId: String,
        name: String
    ) {
        withContext(Dispatchers.IO) {
            var input: BufferedInputStream? = null
            var output: FileOutputStream? = null
            try {
                val url = URL(fileUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 15000
                connection.connect()

                if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                    throw Exception("Server returned HTTP ${connection.responseCode} ${connection.responseMessage}")
                }

                val fileLength = connection.contentLength
                input = BufferedInputStream(url.openStream(), 8192)
                output = FileOutputStream(destFile)

                val data = ByteArray(1024)
                var total: Long = 0
                var count: Int
                var lastProgress = -1

                while (input.read(data).also { count = it } != -1) {
                    // यदि टास्क WorkManager द्वारा कैंसिल कर दिया गया है
                    if (isStopped) {
                        input.close()
                        output.close()
                        destFile.delete()
                        return@withContext
                    }

                    total += count.toLong()
                    if (fileLength > 0) {
                        val progress = (total * 100 / fileLength).toInt()
                        if (progress > lastProgress) {
                            showProgress(notificationId, taskId, name, progress, "Downloading: $progress%")
                            lastProgress = progress
                        }
                    }
                    output.write(data, 0, count)
                }
            } finally {
                output?.flush()
                output?.close()
                input?.close()
            }
        }
    }

    private fun showProgress(
        id: Int,
        taskId: String,
        name: String,
        progress: Int,
        line: String
    ) {
        val intent = Intent(applicationContext, CancelReceiver::class.java).apply {
            putExtra("taskId", taskId)
            putExtra("notificationId", id)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            applicationContext,
            id,
            intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(applicationContext, iUtils.myNotificationChannel)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSmallIcon(R.drawable.ic_download_yellow)
            .setContentTitle(name)
            .setContentText(line)
            .setSound(null)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .setProgress(100, progress, progress == -1)
            .addAction(
                R.drawable.ic_close_24dp,
                applicationContext.getString(R.string.cancel),
                pendingIntent
            )
            .setOngoing(true)
            .build()
        notificationManager?.notify(id, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            var notificationChannel = notificationManager?.getNotificationChannel(iUtils.myNotificationChannel)
            if (notificationChannel == null) {
                val channelName = applicationContext.getString(R.string.app_name)
                notificationChannel = NotificationChannel(
                    iUtils.myNotificationChannel,
                    channelName, NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = channelName
                }
                notificationManager?.createNotificationChannel(notificationChannel)
            }
        }
    }

    companion object {
        const val urlKey = "url"
        const val nameKey = "name"
        const val formatIdKey = "formatId"
        const val acodecKey = "acodec"
        const val vcodecKey = "vcodec"
        const val taskIdKey = "taskId"
        const val extKey = "ext"
    }
}