package com.allvideodown.socialdownloader.utils;

import androidx.core.content.FileProvider;

public class MyFileProvider extends FileProvider {
}
