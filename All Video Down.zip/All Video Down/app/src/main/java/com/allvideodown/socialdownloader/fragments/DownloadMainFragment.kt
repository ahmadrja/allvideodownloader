/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023-2026. All rights reserved.
 *
 */

@file:Suppress("DEPRECATION", "NAME_SHADOWING")

package com.allvideodown.socialdownloader.fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.ProgressDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.Keep
import androidx.appcompat.app.AlertDialog
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.bumptech.glide.Glide
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.MobileAds
import com.allvideodown.socialdownloader.BuildConfig
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.activities.AllSupportedApps
import com.allvideodown.socialdownloader.activities.GalleryActivity
import com.allvideodown.socialdownloader.activities.GetLinkThroughWebView
import com.allvideodown.socialdownloader.activities.MainActivity
import com.allvideodown.socialdownloader.activities.SplashScreen
import com.allvideodown.socialdownloader.activities.newUi.GalleryActivityNewUi
import com.allvideodown.socialdownloader.activities.newUi.StatusSaverActivity
import com.allvideodown.socialdownloader.databinding.FragmentDownloadBinding
import com.allvideodown.socialdownloader.models.InstagramPostDataNew
import com.allvideodown.socialdownloader.services.MyFirebaseMessagingService
import com.allvideodown.socialdownloader.tiktok_methods.InstagramDownloadCloudBypassWebview_method_0_new
import com.allvideodown.socialdownloader.utils.AdsManager
import com.allvideodown.socialdownloader.utils.Constants
import com.allvideodown.socialdownloader.utils.Constants.PREF_CLIP
import com.allvideodown.socialdownloader.utils.DownloadFileMain
import com.allvideodown.socialdownloader.utils.OreoNotification
import com.allvideodown.socialdownloader.utils.SharedPrefsForInstagram
import com.allvideodown.socialdownloader.utils.SharedPrefsMainApp
import com.allvideodown.socialdownloader.utils.iUtils
import com.allvideodown.socialdownloader.utils.iUtils.ShowToast
import com.allvideodown.socialdownloader.webservices.DownloadVideosMain
import io.reactivex.rxjava3.plugins.RxJavaPlugins
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executor

@Keep
class DownloadMainFragment : Fragment() {
    private var myselectedActivity: FragmentActivity? = null
    private var binding: FragmentDownloadBinding? = null
    private var nn: String? = "nnn"
    private var csRunning = false
    lateinit var webViewInsta: WebView
    lateinit var progressDralogGenaratinglink: ProgressDialog
    private lateinit var prefEditor: SharedPreferences.Editor
    lateinit var pref: SharedPreferences
    var myVideoUrlIs: String? = null
    var myInstaUsername: String? = ""
    var myPhotoUrlIs: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDownloadBinding.inflate(inflater, container, false)
        setActivityAfterAttached()
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (activity != null && isAdded) {
            hideKeyboard(requireActivity())
            nn = SharedPrefsMainApp(myselectedActivity).preferencE_inappads

            progressDralogGenaratinglink = ProgressDialog(myselectedActivity!!)
            progressDralogGenaratinglink.setMessage(resources.getString(R.string.genarating_download_link))
            progressDralogGenaratinglink.setCancelable(false)

            pref = myselectedActivity!!.getSharedPreferences(PREF_CLIP, 0)
            prefEditor = pref.edit()
            csRunning = pref.getBoolean("csRunning", false)
            prefEditor.apply()

            createNotificationChannel(myselectedActivity!!)
            configureRxJavaErrorHandler()

            binding!!.ivHelp.setOnClickListener {
                try {
                    binding!!.etURL.setText("")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            binding!!.btnDownload.setOnClickListener {
                val url = binding!!.etURL.text.toString()
                DownloadVideo(url)
            }

            binding?.showinstatext?.visibility =
                if (iUtils.isNonPlayStoreApp) View.VISIBLE else View.GONE

            if (activity != null) {
                val activity: MainActivity? = activity as MainActivity?
                val strtext: String? = activity?.getMyData()
                if (strtext != null && strtext != "") {
                    activity.setmydata("")
                    binding!!.etURL.setText(strtext)
                    val url = binding!!.etURL.text.toString()
                    DownloadVideo(url)
                }
            }

            handleBioMetricTask()

            if (iUtils.isNonPlayStoreApp) {
                binding!!.instaprivatefbprivate.setOnClickListener {
                    val intent = Intent(myselectedActivity, StatusSaverActivity::class.java)
                    intent.putExtra("frag", "download")
                    startActivity(intent)
                }
            }

            binding!!.videomoreBtn.setOnClickListener {
                val intent = Intent(myselectedActivity, AllSupportedApps::class.java)
                startActivity(intent)
            }

            binding!!.ivLink.setOnClickListener {
                val clipBoardManager =
                    myselectedActivity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val primaryClipData = clipBoardManager.primaryClip
                val clip = primaryClipData?.getItemAt(0)?.text.toString()
                binding!!.etURL.text = Editable.Factory.getInstance().newEditable(clip)
                DownloadVideo(clip)
            }

            doAdsStuff()
            if (!iUtils.isNonPlayStoreApp) {
                doNoMetasStuff()
            }
        }
    }

    private fun doAdsStuff() {
        try {
            if (Constants.show_Ads && !BuildConfig.ISPRO && nn == "nnn") {
                MobileAds.initialize(requireActivity()) {
                    AdsManager.loadInterstitialAdAsync((activity as Activity?)!!)
                    AdsManager.loadVideoAdAdmobAsync(
                        (activity as Activity?)!!,
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                            }
                        })
                    LoadAdTaskDownload(myselectedActivity!!, binding!!.flAdplaceholder).execute()
                }
            } else {
                binding!!.flAdplaceholder.visibility = View.GONE
            }
        } catch (_: Exception) {}
    }

    @SuppressLint("StaticFieldLeak")
    private fun doNoMetasStuff() {
        val isBonusAlert = SharedPrefsMainApp(myselectedActivity!!).preferencE_isMetaRemovalShown
        if (!isBonusAlert) {
            if (isAdded) {
                val builder = AlertDialog.Builder(myselectedActivity!!)
                builder.setTitle("Alert!!")
                builder.setCancelable(false)
                builder.setMessage("Support of All Meta related services like (Facebook, instagram, threads and whatsapp status saver) have been removed due to Meta's Copyright Strike. We are sorry for the inconvenience. ")
                builder.setPositiveButton(R.string.rate_it) { dialog, _ ->
                    dialog.dismiss()
                    SharedPrefsMainApp(myselectedActivity!!).preferencE_isMetaRemovalShown = true
                }
                builder.show()
            }
        }
    }

    private fun handleBioMetricTask() {
        try {
            val biometricManager: BiometricManager = BiometricManager.from(myselectedActivity!!)
            when {
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS -> {}
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                    val prefs = myselectedActivity!!.getSharedPreferences("whatsapp_pref", MODE_PRIVATE)
                    val editor = prefs.edit()
                    editor.putBoolean("isBio", false)
                    editor.apply()
                    myselectedActivity!!.runOnUiThread {
                        iUtils.ShowToastError(myselectedActivity, "This device does not have a fingerprint sensor")
                    }
                }
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                    myselectedActivity!!.runOnUiThread {
                        iUtils.ShowToastError(myselectedActivity, "The biometric sensor is currently unavailable")
                    }
                    val prefs = myselectedActivity!!.getSharedPreferences("whatsapp_pref", MODE_PRIVATE)
                    val editor = prefs.edit()
                    editor.putBoolean("isBio", false)
                    editor.apply()
                }
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                    val prefs = myselectedActivity!!.getSharedPreferences("whatsapp_pref", MODE_PRIVATE)
                    val editor = prefs.edit()
                    editor.putBoolean("isBio", false)
                    editor.apply()
                }
            }

            val executor: Executor = ContextCompat.getMainExecutor(myselectedActivity!!)
            val biometricPrompt = BiometricPrompt(
                myselectedActivity!!,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        if (iUtils.isNewUi) {
                            startActivity(Intent(myselectedActivity, GalleryActivityNewUi::class.java))
                        } else {
                            startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
                        }
                    }
                })

            val promptInfo: BiometricPrompt.PromptInfo = BiometricPrompt.PromptInfo.Builder().setTitle("Verify Identity")
                .setDescription("Use your fingerprint or device credentials to Access Gallery ")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build()

            binding!!.rvGallery.setOnClickListener {
                try {
                    val prefs: SharedPreferences = myselectedActivity!!.getSharedPreferences("whatsapp_pref", Context.MODE_PRIVATE)
                    val lang = prefs.getBoolean("isBio", false)
                    if (lang) {
                        biometricPrompt.authenticate(promptInfo)
                    } else {
                        if (iUtils.isNewUi) {
                            startActivity(Intent(myselectedActivity, GalleryActivityNewUi::class.java))
                        } else {
                            startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    if (iUtils.isNewUi) {
                        startActivity(Intent(myselectedActivity, GalleryActivityNewUi::class.java))
                    } else {
                        startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            binding!!.rvGallery.setOnClickListener {
                if (iUtils.isNewUi) {
                    startActivity(Intent(myselectedActivity, GalleryActivityNewUi::class.java))
                } else {
                    startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
                }
            }
        }
    }

    class LoadAdTaskDownload(private val context: Activity, private val frameLayout: FrameLayout) :
        AsyncTask<Void, Void, Unit>() {
        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: Void?) {
            AdsManager.loadAdmobNativeAdAsync(context, frameLayout)
        }
    }

    fun dismissMyDialogFrag() {
        try {
            if (activity != null && isAdded) {
                myselectedActivity?.runOnUiThread {
                    if (!(myselectedActivity as Activity).isFinishing && progressDralogGenaratinglink != null && progressDralogGenaratinglink.isShowing) {
                        progressDralogGenaratinglink.dismiss()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismissMyDialogErrorToastFrag() {
        try {
            if (activity != null && isAdded) {
                myselectedActivity?.runOnUiThread {
                    if (!(myselectedActivity as Activity).isFinishing && progressDralogGenaratinglink != null && progressDralogGenaratinglink.isShowing) {
                        progressDralogGenaratinglink.dismiss()
                        myselectedActivity!!.runOnUiThread {
                            iUtils.ShowToastError(myselectedActivity, myselectedActivity!!.resources.getString(R.string.somthing))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        if (activity != null) {
            val activity: MainActivity? = activity as MainActivity?
            val strtext: String? = activity?.getMyData()
            if (strtext != null && strtext != "") {
                activity.setmydata("")
                binding!!.etURL.setText(strtext)
                DownloadVideo(strtext)
            }
        }
    }

    private fun createNotificationChannel(context: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val oreoNotification = OreoNotification(
                context,
                if (!MyFirebaseMessagingService.isWaku) MyFirebaseMessagingService.DefaultSoundString else MyFirebaseMessagingService.DefaultSoundWakuString
            )
        }
    }

    fun DownloadVideo(url1: String) {
        hideKeyboard(requireActivity())
        progressDralogGenaratinglink.setMessage(resources.getString(R.string.genarating_download_link))

        if (TextUtils.isEmpty(url1.trim()) && url1.trim() == "") {
            ShowToast(myselectedActivity, myselectedActivity!!.resources?.getString(R.string.enter_valid))
        } else {
            val rand_int1 = iUtils.getRandomNumber(2)
            if (rand_int1 == 0) showAdmobAds() else showAdmobAds_int_video()

            var url = url1
            try {
                url = iUtils.extractUrls(url1)[0]
            } catch (_: Exception) {}

            if (!iUtils.checkURL(url.trim())) {
                ShowToast(myselectedActivity, myselectedActivity!!.resources?.getString(R.string.enter_valid))
                return
            }

            SplashScreen.uploadDownloadedUrl(url1)

            if (url.contains("instagram.com")) {
                if (!myselectedActivity!!.isFinishing) {
                    if (!iUtils.isNonPlayStoreApp || !iUtils.isSocialMediaOn("instagram.com")) {
                        ShowToast(myselectedActivity, myselectedActivity!!.resources.getString(R.string.somthing_webiste_panele_block))
                        return
                    }
                    progressDralogGenaratinglink.show()
                    startInstaDownload(url)
                }
            } else if (url.contains("threads.net") || url.contains("audiomack") || url.contains("ok.ru") || url.contains("zili") || url.contains("tiki") || url.contains("vidlit") || url.contains("byte.co") || url.contains("fthis.gr") || url.contains("fw.tv") || url.contains("traileraddict") || url.contains("bemate")) {
                var myurl = url
                try { myurl = iUtils.extractUrls(myurl)[0] } catch (_: Exception) {}
                val intent = Intent(myselectedActivity, GetLinkThroughWebView::class.java)
                intent.putExtra("myurlis", myurl)
                startActivityForResult(intent, 2)
            } else {
                var myurl = url
                try { myurl = iUtils.extractUrls(myurl)[0] } catch (_: Exception) {}
                DownloadVideosMain.Start(myselectedActivity, myurl.trim(), false)
            }
        }
    }

    private fun setActivityAfterAttached() {
        try {
            if (activity != null && isAdded) {
                myselectedActivity = activity
            }
        } catch (e: Exception) {
            myselectedActivity = requireActivity()
        }
    }

    @Keep
    @SuppressLint("JavascriptInterface", "SetJavaScriptEnabled")
    fun startInstaDownload(Url: String) {
        val Urlwi: String?
        try {
            val uri = URI(Url)
            Urlwi = URI(uri.scheme, uri.authority, uri.path, null, uri.fragment).toString()
        } catch (ex: java.lang.Exception) {
            dismissMyDialogFrag()
            ShowToast(myselectedActivity!!, getString(R.string.invalid_url))
            return
        }

        var urlwithoutlettersqp: String? = Urlwi

        if (urlwithoutlettersqp!!.contains("/share/")) {
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val redirectedUrl = getRedirectUrl(urlwithoutlettersqp!!)?.let { redirected ->
                        val uri = URI(redirected)
                        URI(uri.scheme, uri.authority, uri.path, null, uri.fragment).toString()
                    } ?: urlwithoutlettersqp
                    continueInstagramDownload(redirectedUrl)
                } catch (e: Exception) {
                    println("Error handling redirected URL: ${e.message}")
                }
            }
        } else {
            continueInstagramDownload(urlwithoutlettersqp!!)
        }
    }

    suspend fun getRedirectUrl(url: String): String? {
        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            try {
                val initialUrl = URL(url)
                connection = initialUrl.openConnection() as HttpURLConnection
                connection.instanceFollowRedirects = true
                connection.connect()

                val responseCode = connection.responseCode
                if (responseCode in 300..399) {
                    connection.getHeaderField("Location")
                } else {
                    connection.url.toString()
                }
            } catch (e: IOException) {
                null
            } finally {
                connection?.disconnect()
            }
        }
    }

    // ************ SMART AUTO ROUTER (No More Method Dialog) ************
    fun continueInstagramDownload(myUrl: String) {
        var urlwithoutlettersqp: String? = myUrl

        if (urlwithoutlettersqp!!.contains("/reel/")) {
            urlwithoutlettersqp = urlwithoutlettersqp.replace("/reel/", "/p/")
        }
        if (urlwithoutlettersqp.contains("/tv/")) {
            urlwithoutlettersqp = urlwithoutlettersqp.replace("/tv/", "/p/")
        }

        val urlwithoutlettersqp_noa: String = urlwithoutlettersqp
        urlwithoutlettersqp = "$urlwithoutlettersqp?__a=1&__d=dis"

        try {
            val sharedPrefsFor = SharedPrefsForInstagram(myselectedActivity!!)
            if (sharedPrefsFor.preference.preferencE_SESSIONID == "") {
                sharedPrefsFor.clearSharePrefs()
            }
            val map = sharedPrefsFor.preference

            if (map != null && map.preferencE_USERID != null && map.preferencE_USERID != "oopsDintWork" && map.preferencE_USERID != "") {
                // User Logged In -> Auto Fetch Fast Data
                fetchInstagramData(urlwithoutlettersqp, "ds_user_id=" + map.preferencE_USERID + "; sessionid=" + map.preferencE_SESSIONID)
            } else {
                // User NOT Logged In -> Auto Use Webview Bypass
                dismissMyDialogFrag()
                val intent = Intent(myselectedActivity, InstagramDownloadCloudBypassWebview_method_0_new::class.java)
                intent.putExtra("myvidurl", urlwithoutlettersqp_noa)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                myselectedActivity!!.startActivity(intent)
            }
        } catch (e: Exception) {
            dismissMyDialogFrag()
            e.printStackTrace()
            ShowToast(myselectedActivity!!, getString(R.string.error_occ))
        }
    }

    // ************ MEDIA PREVIEW DIALOG CREATOR ************
    private fun showMediaPreviewDialog(urls: List<String>, baseFileName: String, defaultExtension: String) {
        if(urls.isEmpty()) return
        requireActivity().runOnUiThread {
            val dialog = Dialog(requireActivity())
            dialog.setCancelable(true)

            val layout = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(60, 60, 60, 60)
                gravity = Gravity.CENTER
                setBackgroundColor(android.graphics.Color.WHITE)
            }

            val titleView = TextView(requireContext()).apply {
                text = if(urls.size > 1) "Preview (1 of ${urls.size} items)" else "Media Preview"
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(android.graphics.Color.BLACK)
                setPadding(0, 0, 0, 30)
            }

            val imageView = ImageView(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(
                    requireContext().resources.displayMetrics.widthPixels - 150,
                    800
                )
                scaleType = ImageView.ScaleType.FIT_CENTER
            }

            // Using Glide to load preview (works for image and video frame)
            Glide.with(requireContext())
                .load(urls[0])
                .into(imageView)

            val downloadBtn = Button(requireContext()).apply {
                text = if(urls.size > 1) "Download All (${urls.size})" else "Download Now"
                setBackgroundResource(R.drawable.btn_bg_download_screen)
                setTextColor(android.graphics.Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = 50
                }
            }

            layout.addView(titleView)
            layout.addView(imageView)
            layout.addView(downloadBtn)
            dialog.setContentView(layout)

            downloadBtn.setOnClickListener {
                dialog.dismiss()
                urls.forEachIndexed { index, finalUrl ->
                    val ext = if(finalUrl.contains(".mp4") || defaultExtension == ".mp4") ".mp4" else ".png"
                    val finalName = if(urls.size > 1) "${baseFileName}_$index" else baseFileName
                    DownloadFileMain.startDownloading(requireActivity(), finalUrl, finalName, ext)
                }
                Toast.makeText(requireActivity(), "Downloading Started...", Toast.LENGTH_SHORT).show()
            }

            dialog.show()
        }
    }


    fun scrapePost(urlOrShortcode: String, mycookies: String?): String {
        val INSTAGRAM_DOCUMENT_ID = "8845758582119845"
        val shortcode = if (urlOrShortcode.contains("http")) {
            urlOrShortcode.split("/p/").last().split("/")[0]
        } else {
            urlOrShortcode
        }

        val variables = JSONObject().apply {
            put("shortcode", shortcode)
            put("fetch_tagged_user_count", JSONObject.NULL)
            put("hoisted_comment_id", JSONObject.NULL)
            put("hoisted_reply_id", JSONObject.NULL)
        }

        val encodedVariables = URLEncoder.encode(variables.toString(), StandardCharsets.UTF_8.toString())
        val body = "variables=$encodedVariables&doc_id=$INSTAGRAM_DOCUMENT_ID"
        val requestBody = RequestBody.create("application/x-www-form-urlencoded".toMediaTypeOrNull(), body)

        val client = OkHttpClient()
        val request = Request.Builder()
            .url("https://www.instagram.com/graphql/query")
            .post(requestBody)
            .addHeader("Content-Type", "application/x-www-form-urlencoded")
            .addHeader("Cookie", mycookies ?: "")
            .addHeader("User-Agent", "Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("Request failed with status: ${response.code}")
            val jsonResponse = JSONObject(response.body?.string())
            return jsonResponse.getJSONObject("data").getJSONObject("xdt_shortcode_media").toString()
        }
    }

    fun fetchInstagramData(instagramUrl: String, cookies: String?) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val postData = scrapePost(instagramUrl, cookies)
                val postDataModel = InstagramPostDataNew.fromJson(postData)
                val ownerUsername = postDataModel.owner?.username ?: "unknown_user"
                myInstaUsername = ownerUsername

                val edges = postDataModel.edgeSidecarToChildren?.edges
                val mediaUrls = mutableListOf<String>()
                var defaultExt = ".png"

                if (!edges.isNullOrEmpty()) {
                    edges.forEach { edgeNode ->
                        edgeNode.node?.let { node ->
                            if (node.isVideo == true) {
                                node.videoURL?.let { mediaUrls.add(it); defaultExt = ".mp4" }
                            } else {
                                node.displayResources?.lastOrNull()?.src?.let { mediaUrls.add(it) }
                            }
                        }
                    }
                } else {
                    if (postDataModel.isVideo == true) {
                        postDataModel.videoURL?.let { mediaUrls.add(it); defaultExt = ".mp4" }
                    } else {
                        postDataModel.displayResources?.lastOrNull()?.src?.let { mediaUrls.add(it) }
                    }
                }

                // Show Dynamic UI Preview
                dismissMyDialogFrag()
                showMediaPreviewDialog(mediaUrls, "${ownerUsername}_${System.currentTimeMillis()}", defaultExt)

            } catch (e: Exception) {
                e.printStackTrace()
                showToast(resources.getString(R.string.somthing))
                dismissMyDialogFrag()
            }
        }
    }

    private fun showToast(message: String) {
        CoroutineScope(Dispatchers.Main).launch {
            Toast.makeText(myselectedActivity, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAdmobAds_int_video() {
        if (Constants.show_Ads && !BuildConfig.ISPRO && nn == "nnn") {
            AdsManager.showVideoAdAdmobAsync(requireActivity(), { }, false)
        }
    }

    private fun showAdmobAds() {
        if (Constants.show_Ads && !BuildConfig.ISPRO && nn == "nnn") {
            AdsManager.showAdmobInterstitialAd(activity as Activity?, object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    super.onAdDismissedFullScreenContent()
                    AdsManager.loadInterstitialAdAsync((activity as Activity?)!!)
                }
            }, false)
        }
    }

    private fun configureRxJavaErrorHandler() {
        RxJavaPlugins.setErrorHandler { e: Throwable ->
            if (e is InterruptedException) return@setErrorHandler
        }
    }

    private fun hideKeyboard(activity: Activity) {
        try {
            val inputManager = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val currentFocusedView = activity.currentFocus
            if (currentFocusedView != null) {
                inputManager.hideSoftInputFromWindow(currentFocusedView.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}