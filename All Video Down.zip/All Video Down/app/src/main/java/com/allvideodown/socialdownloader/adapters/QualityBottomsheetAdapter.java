/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2026 . All rights reserved.
 *
 */

package com.allvideodown.socialdownloader.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.allvideodown.socialdownloader.R;
import com.allvideodown.socialdownloader.models.dlapismodels.Format;
import com.allvideodown.socialdownloader.models.dlapismodels.Video;
import com.allvideodown.socialdownloader.utils.DownloadFileMain;
import com.allvideodown.socialdownloader.utils.iUtils;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QualityBottomsheetAdapter extends RecyclerView.Adapter<QualityBottomsheetAdapter.ViewHolder> {

    private final String vidSource;
    boolean issingle;
    boolean hasMultiAlbumb = false;
    private Activity context;
    private List<Format> filesList;
    private List<Video> filesVideoList;
    private String vidurl;

    // Constructor for Format List
    public QualityBottomsheetAdapter(Activity context, List<Format> filesList, String source, boolean issingle) {
        this.context = context;
        this.filesList = addtoarrayno_m3u8(filesList);
        this.issingle = issingle;
        this.vidSource = source;
    }

    // Constructor for Video List
    public QualityBottomsheetAdapter(Activity context, String source, boolean issingle, List<Video> filesList, boolean hasMultiAlbumb) {
        this.context = context;
        this.filesVideoList = filesList;
        this.issingle = issingle;
        this.hasMultiAlbumb = hasMultiAlbumb;
        this.vidSource = source;

        removeRepeatedVideos();
    }

    // Constructor for Single URL
    public QualityBottomsheetAdapter(Activity context, String url, String source, boolean issingle) {
        this.context = context;
        this.vidurl = url;
        this.issingle = issingle;
        this.vidSource = source;
    }

    /**
     * Extract quality from a format string
     */
    public static String extractQuality(String format) {
        if (format == null) return "unknown";

        // First try to find quality in parentheses like (480p)
        Pattern parenthesesPattern = Pattern.compile("\\((\\d+p)\\)");
        Matcher parenthesesMatcher = parenthesesPattern.matcher(format);

        if (parenthesesMatcher.find()) {
            return parenthesesMatcher.group(1);
        }

        // If not found in parentheses, try to extract from resolution (e.g., 720x1280)
        Pattern resolutionPattern = Pattern.compile("(\\d+)x\\d+");
        Matcher resolutionMatcher = resolutionPattern.matcher(format);

        if (resolutionMatcher.find()) {
            return resolutionMatcher.group(1) + "p";
        }

        return format;
    }

    @NonNull
    @Override
    public QualityBottomsheetAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_quality_bottomfragment, parent, false);
        return new ViewHolder(view);
    }

    private int getMediaTypeIconResId(Object media) {
        if (media instanceof Video) {
            Video video = (Video) media;
            if (video.getURL() != null && video.getURL().contains("http") &&
                    !video.getURL().contains(".m3u8")) {
                if (video.getEXT() != null && (video.getEXT().equals("m4a") ||
                        video.getEXT().equals("mp3") ||
                        video.getEXT().equals("wav"))) {
                    return R.drawable.music_player;
                } else {
                    return R.drawable.video_camera;
                }
            }
        } else if (media instanceof Format) {
            Format format = (Format) media;
            if (format.getURL() != null && format.getURL().contains("http") &&
                    !format.getURL().contains(".m3u8")) {
                if ((format.getAcodec() != null && !format.getAcodec().equals("none")) ||
                        (format.getEXT() != null && (format.getEXT().equals("m4a") ||
                                format.getEXT().equals("mp3") ||
                                format.getEXT().equals("wav")))) {
                    return R.drawable.music_player;
                } else {
                    return R.drawable.video_camera;
                }
            }
        }
        return R.drawable.video_camera; // Default to video
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NotNull QualityBottomsheetAdapter.ViewHolder holder, final int position) {
        if (issingle) {
            holder.resolution.setText("HD");
            holder.fileSize.setText("undefined");
            holder.typeicon.setImageResource(R.drawable.video_camera);
            holder.downloadbtnd.setOnClickListener(v ->
                    DownloadFileMain.startDownloading(context, vidurl, vidSource + "_" + System.currentTimeMillis(), ".mp4"));
        } else {
            if (hasMultiAlbumb && filesVideoList != null && !filesVideoList.isEmpty()) {
                final Video files = filesVideoList.get(position);
                holder.typeicon.setImageResource(getMediaTypeIconResId(files));

                if (files.getURL() != null && !files.getURL().contains(".m3u8") && files.getProtocol().contains("http")) {
                    String formatString = files.getFormat() != null && files.getFormat().length() > 20 && files.getFormatID() != null
                            ? files.getFormatID() : files.getFormat();

                    String finalResolution = extractQuality(String.format("%s", formatString));
                    holder.resolution.setText(finalResolution);
                    holder.resolution.setSelected(true);
                    holder.resolution.setSingleLine(true);

                    holder.fileSize.setText("undefined");

                    holder.downloadbtnd.setOnClickListener(v -> {
                        String ext = files.getEXT();
                        if (ext == null || ext.equals("com") || ext.equals("")) ext = "mp4";
                        DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + System.currentTimeMillis(), "." + ext);
                    });
                }
            } else if (filesList != null && !filesList.isEmpty()) {
                final Format files = filesList.get(position);
                holder.typeicon.setImageResource(getMediaTypeIconResId(files));

                if (files.getURL() != null && !files.getURL().contains(".m3u8") && files.getProtocol().contains("http")) {
                    String formatString = files.getFormat() != null && files.getFormat().length() > 20 && files.getFormatNote() != null
                            ? files.getFormatNote() : files.getFormat();

                    String finalResolution = extractQuality(String.format("%s", formatString));
                    holder.resolution.setText(finalResolution);
                    holder.resolution.setSelected(true);
                    holder.resolution.setSingleLine(true);

                    String formatedsizew = iUtils.getStringSizeLengthFile(files.getFilesize());
                    if (formatedsizew != null) {
                        formatedsizew = formatedsizew.replace(",", ".");
                    }
                    holder.fileSize.setText(formatedsizew != null && !formatedsizew.equals("") ? formatedsizew : "undefined");

                    holder.downloadbtnd.setOnClickListener(v -> {
                        String ext = files.getEXT();
                        if (ext == null || ext.equals("com") || ext.equals("")) ext = "mp4";
                        DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + System.currentTimeMillis(), "." + ext);
                    });
                }
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    void removeRepeatedVideos() {
        if (filesVideoList == null || filesVideoList.isEmpty()) return;

        Map<String, Video> uniqueQualityVideos = new HashMap<>();

        for (Video video : filesVideoList) {
            String formatString = video.getFormat() != null && video.getFormat().length() > 20 && video.getFormatID() != null
                    ? video.getFormatID()
                    : video.getFormat();

            String quality = extractQuality(formatString);

            if (!uniqueQualityVideos.containsKey(quality)) {
                uniqueQualityVideos.put(quality, video);
            }
        }

        filesVideoList.clear();
        filesVideoList.addAll(uniqueQualityVideos.values());

        filesVideoList.sort((video1, video2) -> {
            String formatString1 = video1.getFormat() != null && video1.getFormat().length() > 20 && video1.getFormatID() != null
                    ? video1.getFormatID() : video1.getFormat();
            String formatString2 = video2.getFormat() != null && video2.getFormat().length() > 20 && video2.getFormatID() != null
                    ? video2.getFormatID() : video2.getFormat();

            String quality1 = extractQuality(formatString1);
            String quality2 = extractQuality(formatString2);

            int qualityValue1 = parseQualityValue(quality1);
            int qualityValue2 = parseQualityValue(quality2);

            return Integer.compare(qualityValue2, qualityValue1);
        });

        notifyDataSetChanged();
    }

    private int parseQualityValue(String quality) {
        try {
            if (quality != null && quality.contains("p")) {
                String numericPart = quality.substring(0, quality.indexOf("p")).replaceAll("[^0-9]", "");
                if (!numericPart.isEmpty()) {
                    return Integer.parseInt(numericPart);
                }
            }
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public int getItemCount() {
        if (hasMultiAlbumb && filesVideoList != null) {
            return filesVideoList.size();
        }
        return issingle ? 1 : (filesList != null ? filesList.size() : 0);
    }

    List<Format> addtoarrayno_m3u8(List<Format> fromList) {
        if (fromList != null) {
            List<Format> toList = new ArrayList<>();
            for (int i = 0; i < fromList.size(); i++) {
                if (fromList.get(i).getURL() != null && !fromList.get(i).getURL().contains(".m3u8")) {
                    toList.add(fromList.get(i));
                }
            }
            return toList;
        }
        return new ArrayList<>();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView resolution;
        TextView fileSize;
        ImageView downloadbtnd, typeicon;

        public ViewHolder(View itemView) {
            super(itemView);
            resolution = itemView.findViewById(R.id.resolution);
            typeicon = itemView.findViewById(R.id.typeicon);
            fileSize = itemView.findViewById(R.id.file_size);
            downloadbtnd = itemView.findViewById(R.id.download_button);
        }
    }
}