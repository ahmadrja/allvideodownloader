/*
 * *
 * * Copyright (c) 2026. All rights reserved.
 * *
 */

package com.allvideodown.socialdownloader.utils.work

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.work.WorkManager
import com.allvideodown.socialdownloader.R

class CancelReceiver : BroadcastReceiver() {
    private val TAG = "CancelReceiver"

    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d(TAG, "Task Canceler called")
        try {
            // Null Safety Check (Crash से बचने के लिए)
            if (intent == null || context == null) return

            val taskId = intent.getStringExtra("taskId")
            val notificationId = intent.getIntExtra("notificationId", 0)

            if (taskId.isNullOrEmpty()) return

            // ✅ [FIX]: YoutubeDL को हटा दिया गया है।
            // अब हम सीधे WorkManager के माध्यम से बैकग्राउंड डाउनलोड टास्क को रोकेंगे।
            Log.d(TAG, "Canceling WorkManager Task (id:$taskId)")
            WorkManager.getInstance(context).cancelAllWorkByTag(taskId)

            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as
                        NotificationManager?

            Toast.makeText(context, R.string.taskcancel, Toast.LENGTH_LONG).show()
            notificationManager?.cancel(notificationId)

        } catch (e: Exception) {
            Log.d(TAG, "Task Failed CancelReceiver: ${e.message}")
        }
    }
}