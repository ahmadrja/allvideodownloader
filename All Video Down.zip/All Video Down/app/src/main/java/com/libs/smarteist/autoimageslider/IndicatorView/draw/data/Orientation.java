package com.libs.smarteist.autoimageslider.IndicatorView.draw.data;

public enum Orientation {HORIZONTAL, VERTICAL}
