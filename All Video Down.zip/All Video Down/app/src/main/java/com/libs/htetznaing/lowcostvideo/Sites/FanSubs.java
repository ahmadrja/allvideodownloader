package com.libs.htetznaing.lowcostvideo.Sites;

import static com.libs.htetznaing.lowcostvideo.Utils.Utils.putModel;
import static com.libs.htetznaing.lowcostvideo.Utils.Utils.sortMe;

import com.libs.androidnetworking.AndroidNetworking;
import com.libs.androidnetworking.error.ANError;
import com.libs.androidnetworking.interfaces.StringRequestListener;
import com.libs.htetznaing.lowcostvideo.LowCostVideo;
import com.libs.htetznaing.lowcostvideo.Model.XModel;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;

/*
This is direct link getter for FanSubs
    By
Khun Htetz Naing
 */

public class FanSubs {
    public static void fetch(String url, final LowCostVideo.OnTaskCompleted onComplete) {
        AndroidNetworking.get(url)
                .build()
                .getAsString(new StringRequestListener() {
                    @Override
                    public void onResponse(String response) {
                        ArrayList<XModel> models = new ArrayList<>();
                        Document document = Jsoup.parse(response);
                        if (document.html().contains("<source")) {
                            Elements element = document.getElementsByTag("source");
                            for (int i = 0; i < element.size(); i++) {
                                Element temp = element.get(i);
                                if (temp.hasAttr("src")) {
                                    String url = temp.attr("src");
                                    putModel(url, temp.attr("label"), models);
                                }
                            }
                        }
                        if (models.size() != 0) {
                            onComplete.onTaskCompleted(sortMe(models), true);
                        } else onComplete.onError();
                    }

                    @Override
                    public void onError(ANError anError) {
                        System.out.println(anError.getErrorBody());
                        onComplete.onError();
                    }
                });
    }
}
